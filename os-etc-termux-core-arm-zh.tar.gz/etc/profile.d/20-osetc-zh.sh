# OS-ETC-IRIDIS: 中文汉化 profile（由 ETQWFD 注入）
# 中文提示符
export PS1='\[\033[1;36m\]OS-ETC\[\033[0m\] \[\033[1;32m\]\u\[\033[0m\]@\[\033[1;35m\]\h\[\033[0m\]:\[\033[1;34m\]\w\[\033[0m\]\$ '

# 常用中文别名
alias ll='ls -la'
alias la='ls -A'
alias l='ls -CF'
alias cls='clear'
alias 打开='cd'
alias 帮助='osetc-help'
alias 更新='apt update'
alias 安装='apt install'

# 中文帮助命令
osetc-help() {
  cat /share/doc/OS-ETC-README-zh.txt 2>/dev/null || cat /usr/share/doc/OS-ETC-README-zh.txt 2>/dev/null
}

# 提示软件源（北京清华镜像）
if [ -n "$(command -v apt)" ]; then
  echo "[OS-ETC] 软件源已配置为北京清华 TUNA 镜像（mirrors.tuna.tsinghua.edu.cn）"
fi

# locale 提示（如需中文命令输出可执行：apt install coreutils-locales）
export LANG="${LANG:-C.UTF-8}"
